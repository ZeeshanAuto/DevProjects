import React, { useState } from "react";
import Tesseract from "tesseract.js";

function OCRComponent() {
 
}

export default OCRComponent;
