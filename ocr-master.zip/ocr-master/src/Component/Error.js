import React from "react";

const Error = () => {
  const errStyle = {
    backGroundColor: "black",
    fontSize: "400px",
    color: "black",
  };
  return <div style={errStyle}>Error</div>;
};

export default Error;
