import "./App.css";
import GetImage from "./Component/GetImage";

function App() {
  return (
    <div className='App'>
      <GetImage />
    </div>
  );
}

export default App;
