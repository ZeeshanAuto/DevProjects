# electron-publish

Part of [electron-builder](https://github.com/electron-userland/electron-builder). 

See the [Publishing Artifacts](https://www.electron.build/configuration/publish) for more information.

Can be used standalone.