#!/usr/bin/env node

// https://github.com/pnpm/pnpm/issues/1801
require("./out/cli/cli")
