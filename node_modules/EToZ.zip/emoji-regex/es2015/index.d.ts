declare module 'emoji-regex/es2015' {
  function emojiRegex(): RegExp;

  export = emojiRegex;
}
