'use strict';

// https://262.ecma-international.org/6.0/#sec-toobject

module.exports = require('es-object-atoms/ToObject');
