# electron-builder-squirrel-windows

Plugin for [electron-builder](https://github.com/electron-userland/electron-builder) to build Squirrel.Windows installer.