module.exports = require("core-js-compat/get-modules-list-for-target-version");
