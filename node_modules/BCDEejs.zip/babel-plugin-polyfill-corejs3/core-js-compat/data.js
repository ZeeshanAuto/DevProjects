module.exports = require("core-js-compat/data");
