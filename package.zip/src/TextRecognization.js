import React, { useState } from 'react';
import Tesseract from 'tesseract.js';

const TextRecognition = () => {
  const [image, setImage] = useState(null);
  const [extractedText, setExtractedText] = useState('');

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImage(file);

    Tesseract.recognize(
      file,
      'eng', // You can change the language here ('eng' for English)
      { logger: (m) => console.log(m) }
    ).then(({ data: { text } }) => {
      setExtractedText(text);
    });
  };

  return (
    <div>
      <input type="file" accept="image/*" onChange={handleImageChange} />
      {image && <img src={URL.createObjectURL(image)} alt="Uploaded" />}
      <div>
        <h2>Extracted Text:</h2>
        <p>{extractedText}</p>
      </div>
    </div>
  );
};
export default TextRecognition;