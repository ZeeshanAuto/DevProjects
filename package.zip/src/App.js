import logo from './logo.svg';
import './App.css';
import React from 'react';
import './App.css';
//import ImageUploader from './ImageUploader';
import TextRecognition from './TextRecognization';

function App() {
  return (
    <div>
    <h1>Image to Text Converter</h1>
    <TextRecognition />
    </div>
  );
}

export default App;
